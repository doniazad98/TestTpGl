/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.emp.rebot;

import java.util.HashSet;
import java.util.Set;


/**
 *
 * @author hp ENVY
 */

public class Rebot {
    int x,y;
    Orientation1 o ;
    Set<Listner> observers = new HashSet<>();
    void tournerDroit(){
        if(o==Orientation1.HAUT)o=Orientation1.DROITE;
        if(o==Orientation1.DROITE)o=Orientation1.BAS;
        if(o==Orientation1.BAS)o=Orientation1.GAUCHE;
        if(o==Orientation1.GAUCHE)o=Orientation1.HAUT;
    
    }
    void tournerGauche(){
         if(o==Orientation1.HAUT)o=Orientation1.GAUCHE;
        if(o==Orientation1.GAUCHE)o=Orientation1.BAS;
        if(o==Orientation1.BAS)o=Orientation1.DROITE;
        if(o==Orientation1.DROITE)o=Orientation1.HAUT;
    }
    void avancer(){
        
    
    }

    public Rebot(int x, int y, Orientation1 o) {
        this.x = x;
        this.y = y;
        this.o = o;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public Orientation1 getO() {
        return o;
    }

    public void setO(Orientation1 o) {
        this.o = o;
    }
    
    
    void addListener (Listner n) {
		observers.add(n) ;
	}
	
	void removeListener (Listner n) {
		observers.remove(n) ;
	}
	
	void notifier () {
		for (Listner e: observers) {
			e.updateposition();
		}
	}
    
}
