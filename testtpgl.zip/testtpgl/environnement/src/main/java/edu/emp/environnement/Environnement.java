/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.emp.environnement;
import edu.emp.rebot.Listner;

/**
 *
 * @author hp ENVY
 */
public class Environnement implements Listner{
    public boolean[][] matrice=new boolean[10][10];

    @Override
    public void updateposition() {
        
    }

    public boolean[][] getMatrice() {
        return matrice;
    }

    public void setMatrice(boolean[][] matrice) {
        this.matrice = matrice;
    }

    public Environnement() {
      for(int i=0;i<10;i++){
          for(int j=0;j<10;j++){
              matrice[i][j]=true;
          }
       
      }
      matrice[5][6]=false;
      matrice[1][2]=false;
      matrice[8][9]=false;
      matrice[4][4]=false;
        
    }
    
}
