/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.emp.main;

import edu.emp.environnement.Environnement;


import edu.emp.gui.Maiz;

import edu.emp.rebot.Orientation1;
import edu.emp.rebot.Rebot;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import org.emp.gl.core.lookup.Lookup;
//import edu.emp.Rebot.rebot.Rebot;


/**
 *
 * @author hp ENVY
 */
public class Main {
     static {
        // initialisation du Lookup 
        Lookup.getInstance().register(Rebot.class, new Rebot(1,1,Orientation1.DROITE) ); 
        Lookup.getInstance().register(Environnement.class, new Environnement() ); 
       // Lookup.getInstance().register(MessagingService.class, new MessagingServiceImpl() ); 
    }

    /**
     * @param args the command line arguments
     */
    /*public static void main(String[] args) {
        // TODO code application logic here
        Environnement envi = new Environnement();
        Orientation1 a=Orientation1.DROIT;
        
        Rebot r=new Rebot(0,0,a);
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new guienvi(r,envi).setVisible(true);
            }
        });
                
    }*/
    public static void main(String[] args) {
    
    
    Environnement envi = new Environnement();
    Rebot r=new Rebot(1,1,Orientation1.DROITE);
    //Maiz m=new Maiz(envi,r);
    java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                 new Maiz(envi ,r).setVisible(true);
                 
                
            }});
 
    
 
}
    
}
